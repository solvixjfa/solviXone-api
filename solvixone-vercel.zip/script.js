document.getElementById("send").addEventListener("click", () => {
  fetch("/api/send-email", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      template_id: "ynrw7gyqw2k42k8e",
      from: { email: "noreply@mailersend.net", name: "SolviXone" },
      to: [{ email: "jeffry4job@gmail.com", name: "Jeffry" }],
      variables: [{
        email: "jeffry4job@gmail.com",
        substitutions: [
          { var: "order_number", value: "#INV-009876" },
          { var: "product", value: "SolviX AI Pack" },
          { var: "shipping", value: "JNE Express" }
        ]
      }]
    })
  })
  .then(res => res.json())
  .then(data => {
    console.log("✅ Email sent:", data);
    alert("Email berhasil dikirim!");
  })
  .catch(err => {
    console.error("❌ Error:", err);
    alert("Gagal mengirim email");
  });
});